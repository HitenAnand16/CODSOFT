<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "travel_login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$Where_to = $_POST['where'];
$How_Many = $_POST['howmany'];
$Arrival = $_POST['arrival'];
$Departure = $_POST['departure'];

$sql = "INSERT INTO login (Where_to, How_Many, Arrival, Departure) VALUES ('$Where_to', '$How_Many', '$Arrival', '$Departure')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "Record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
?>