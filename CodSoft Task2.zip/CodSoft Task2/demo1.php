<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "travel_login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['rname'];
$email = $_POST['remail'];
$number = $_POST['rnumber'];
$subject = $_POST['rsubject'];
$message = $_POST['rmessage'];

$sql = "INSERT INTO contact (Where_to, How_Many, Arrival, Departure) VALUES ('$name', '$email', '$number', '$subject', '$message')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "Record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
?>